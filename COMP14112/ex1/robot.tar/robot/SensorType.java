package robot;

public enum SensorType{

  LEFT_SENSOR, FORWARD_SENSOR, RIGHT_SENSOR}
