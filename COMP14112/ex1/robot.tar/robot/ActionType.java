package robot; 

public enum ActionType{

  TURN_LEFT, GO_FORWARD, TURN_RIGHT}
